source("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/Radionica svjetlost/paketi_ucitavanje.R")


#Glavni repozitorij ili spremište paketa nalazi se na web stranici CRAN - The Comprehensive R Archive Network. 
#Trenutačno (jesen 2019.) postoji oko 15,000 paketa na CRAN-u, 
#a cijeli popis se može pronaći na poveznici: https://cran.r-project.org/web/packages/available_packages_by_name.html.

#**IZRADA VARIJABLI**  

#Varijable su imenovani spremnici u koje se pohranjuju vrijednosti. 

 
#operator za pridruživanje vrijednosti varijabli je "<-" (skraćeno [Alt] + [-]).
#ctrl + enter za izvođenje naredbi

a <- 1
b <- 1L
c <- "1"
d <- TRUE


#Tip podatka neke varijable možemo provjeriti funkcijom typeof():
typeof(a)
typeof(b)
typeof(c)
typeof(d)

#Funkcije "is." i "as."

#Jezik R ima funkcije is. i as. koje u kombinaciji s tipom podatka mogu provjeriti je li neki objekt određenoga tipa, 
#odnosno pretvoriti objekt iz jednog tipa u drugi 

is.integer(b)  # funkcijom is. testiramo je li objekt nekog tipa
is.double(b)
is.numeric(b)

b <- as.character(b)  # funkcijom as. konvertiramo objekt u drugi tip
typeof(b)

#**OSNOVNE STRUKTURE PODATAKA**

##**VEKTORI**
#Vektor je uređeni niz elemenata istoga tipa. Izrađuje se pomoću funkcije c() (od engl. combine).

#Primjer izrade vektora različitih tipova:
a <- c(TRUE, FALSE, T, F)
b <- rep(c(1, 2, 3), times=2)
c <- c(7, 4, 8, 8, 5, 10)
d <- seq(1, 10, by = 2)

### Operacije nad vektorima
t <- c(1, 2, 3, 4, 5)
t*2
t+10
t^2
t*3+5

#Izračunajte zbroj svih elemenata (sum()), minimalnu (min()), maksimalnu (max()) i srednju vrijednost (mean()) vektora t:
sum(t)
min(t)
max(t)
mean(t)

#Operacije nad dvama vektorima.
t <- c(1, 2, 3, 4, 5)
s <- c(0, 2, 4, 6, 8)

t+s
t/s
t*s
sum(t*s)

t>s
t!=s
t==s

t <- c(1, 2, 3, 4, 5)
s <- c(3, 6, 9)

#Ako dva vektora nad kojima se izvršava vektorizirana operacija nisu jednakih duljina, 
#sustav R će ih napraviti jednako dugima tako da reciklira odnosno replicira kraći vektor dok ne postane jednake duljine kao dulji vektor. 
#U slučaju kada manjeg vektora na kraju treba odrezati, R će dati upozorenje, ali i rezultat.


#**MATRICE**
#Matrica se izrađuje funkcijom matrix(), u prozor Help u oknu Files upišite matrix da dobijete opis te funkcije.

m <- matrix(data = 1:12, nrow = 3, ncol = 4)

#Nazivi redaka i stupaca mogu se zadati pomoću atributa dimnames.
m <- matrix(1:4, 2, 2, 
            dimnames=list(c("Gore", "Dolje"), c("Lijevo", "Desno")))

#Ako se u operatoru pridruživanja izostavi prvi argument, kao npr.
#m[, 3] dobit će se treći stupac.
#Ako se u operatoru pridruživanja izostavi drugi argument, npr.
#m[3,], dobit će se treći redak.

m[1,]
m[,2]

#**LISTE**
#Liste su objekti koji mogu sadržavati elemente različitih tipova, uključujući i druge objekte poput liste, matrice, funkcije, itd.
#Liste se stvaraju pomoću funkcije list().

lista <- list(10, "Ana", c(FALSE, TRUE, TRUE), matrix(1:20, nrow=5, ncol=4))
lista

#Svaki element liste označen je dvostrukom uglatom zagradom [[]] i tako se može i selektirati.
lista[[3]]
lista[[3]][2]

#Imenovanje elemenata liste može se izvršiti, kao i kod vektora, funkcijom names() ili izravno tijekom izrade liste.
names(lista) <- c("broj", "ime", "status", "mjerenja")
lista


#**PODATKOVNI OKVIRI**
#Podatkovni okviri su dvodimenzionalni skupovi podataka koji sadrže elemente različitih tipova, pri čemu svaki njegov stupac unutar sebe sadrži isti tip podatka i svi stupci su istih dimenzija.
#**Svaki stupac možemo shvatiti kao vektor, a svaki redak kao listu.**
#Podatkovni okviri posjeduju svojstva i matrice i liste, pa nad njima možemo primijenjivati funkcije poput 
#names(), colnames(), rownames(), dim(), length(), ncol(), nrow(), rbind(), cbind(), itd.


#Primjer izrade podatkovnog okvira pomoću funkcije data.frame():
Film <- c("Black Panther", "Star Wars: The Last Jedi", "Rogue One: A Star Wars Story", "Star Wars: The Force Awakens", "American Sniper")
Godina <- c(2018, 2017, 2016, 2015, 2014)
Zarada <- c(700059566, 620181382, 532177324, 936662225, 350126372)
Distributer <- c("Buena Vista", "Buena Vista", "Buena Vista", "Buena Vista", "Warner Bros")

toplista <- data.frame(Film,Godina,Zarada,Distributer)
toplista

#Nazivi stupaca odnosno varijabli mogu se zadati ili promijeniti funkcijom names().
#Isto se može napraviti i funkcijom colnames().
names(toplista) <- c("Movie", "Year", "Profit", "Distributor")
names(toplista)[1] <- "SF_movies"
toplista

#Nazivi redaka zadaju se funkcijom rownames().
rownames(toplista)<- c("1.", "2.", "3.", "4.", "5.")
toplista

#Selektiranje elemenata podatkovnog okvira
#S obzirom na to da podatkovni okviri posjeduju svojstva i matrica i listi, pojedine elemente možemo dohvatiti operatorima "[,]" i "\$".

#stupac podatkovnog okvira:
toplista["Year"]  
toplista[2]
toplista$Year #dalje u radu korisiti ćemo ovaj pristup
toplista[,2]

#red podatkovnog okvira:
toplista[1,]

#Dohvaćanje pojedinih elementa unutar stupaca može se izvršiti na bilo koji od sljedećih načina:
toplista$SF_movies[1]
toplista[1,2]
toplista[[2]][1]

#Ispišite prva tri retka i prva dva stupca podatkovnog okvira topLista.
toplista[1:3, 1:2]

#Izbrišite stupac Distributor.
toplista2 <- toplista[-4]
toplista2

#ili

toplista2$Year <- NULL
toplista2

#Izbrišite prvi redak
toplista3 <- toplista[-1,]
toplista3

#**Podskup podatkovnog okvira**
#Izaberite sve filmove iz podatkovnog okvira čiji distributer nije Buena Vista
toplista4 <- subset(toplista, Distributer != "Buena Vista")

#ili

toplista4 <- toplista %>% filter(toplista$Distributer != "Buena Vista")


#**Podatkovni okviri ugrađeni u R**

#Treći način dolaska do podatkovnih okvira su skupovi podataka koji su već ugrađeni u sustav R ili u pakete.
#Popis svih dostupnih podatkovnih skupova može se dobiti naredbom data():
data()

#Za svaki takav podatkovni skup postoji dokumentacija u kojoj su dane informacije o skupu i varijablama.
#Možemo ih dobiti standardnim putem pomoću naredbe "?" ili direktnim upisom u karticu Help.

#Podatkovni okvir "iris" jedan je od korištenijih i dio je ugrađene zbirke podataka "datasets" sustava R.
#Poziva se naredbom data(iris).
data(iris)
iris
?iris


#**RAD S DATUMIMA**

#U sustavu R postoje tri klase kojima se može zabilježiti vrijeme:
  
#* klasa Date – pohranjuje datum kao broj dana od 1.1.1970 UTC.
#* klase POSIXct – pohranjuje datum i vrijeme kao broj sekundi od 1.1.1970 UTC. 
#* klasa POSIXlt – pohranjuje datum i vrijeme u obliku liste (hour, min, sec, mon,...) 
#* čime je lakše dohvatiti pojedini element datuma. 


#Funkcija as.Date() prebacuje datum zapisan kao tekst (engl. *character*) u datum klase Date, a
#* funkcije as.POSIXct()/as.POSIXlt() prebacuju datum i vrijeme zapisane
#* kao tekst u vremenski zapis tipa POSIXct/POSIXlt. 
#* Sve tri funkcije nude mogućnost odabira raznih formata datuma i vremena, 
#* dok funkcije as.POSIXct() i as.POSIXlt() omogućuju i kontrolu vremenske zone.



#Ako se neki zapis želi pohraniti kao datum, ali je zapisan u nestandardnom obliku, 
#onda se as.Date poziva s dodatnim argumentom "format" u kojem se format datuma opiše pomoću sljedeće sintakse:
  
#  |Šifra|Značenje|
#  |%d|dan u mjesecu (broj)|
#  |%m|mjesec (broj)|
#  |%b|mjesec (skraćeni naziv)|
#  |%B|mjesec (puni naziv)|
#  |%y|godina (2 znamenke)|
#  |%Y|godina (4 znamenke)|
  
datum <- "23.10.2019"  #znakovni tip (character)
datum <- as.Date(datum, format = "%d.%m.%Y")  #datum je sada postao klase Date
datum  #pri ispisu će imati standardni format datuma

datum1 <- "16/10/00"
datum2 <- "27. travanj, 2001"  
datum3 <- "02/14/2016"

datum1 <- as.Date(datum1, format="%d/%m/%y")
datum2 <- as.Date(datum2, format="%d. %B, %Y")
datum3 <- as.Date(datum3, format="%m/%d/%Y")

datum1
datum2
datum3

#**Vremenske zone**

#Vremenske zone kontroliraju se argumentom tz().

?tz()

#Popis mogućih vremenskih zona (Olsonove vremenske zone) dobije se naredbom OlsonNames(), 
OlsonNames()

#vremensku zonu iz regionalnih postavki računala dobije se naredbom Sys.timezone().
Sys.timezone()

