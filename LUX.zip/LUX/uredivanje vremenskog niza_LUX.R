source("C:/Users/..put your path to the script here../paketi_ucitavanje.R")

Sys.setlocale("LC_TIME", "C")

#**Task 3 a): Based on the plotted raw time-series data, create a subset of data by applying** 
#* **dplyr pipeline function %>% and filter function**
#* new datasets are described as n_l0, n_l8, n_l8m

#**0 meters**
n_l0 <- l0 %>% filter(`Intensity [Lux]` < x) #put your value here


plot_ly(data = n_l0, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines')%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "Surface - 1 min interval without extremes")

#**8 meters: 1 minute interval**
n_l8 <- l8 %>% filter(`Intensity [Lux]` < x) #put your value here

plot_ly(data = n_l8, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines')%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 m - 1 min interval without extremes")

#**8 meters: 5 minute interval**
n_l8m <- l8m %>% filter(`Intensity [Lux]` < x) #put your value here

plot_ly(data = n_l8m, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines')%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 m -5 min interval without extremes")

#**Task 3 b): look at this plot to compare edited minute and 5 minute interval data measured at 8 m. How do curves match?**
plot_ly(data = n_l8m, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines',
        name = "raw 5 min time interval")%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 m : 5 min interval data")%>% 
  add_lines(data = n_l8,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            name = "filtered from 1 min time interval")
