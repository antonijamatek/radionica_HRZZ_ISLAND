source("C:/Users/..put your path to the script here../paketi_ucitavanje.R")

Sys.setlocale("LC_TIME", "C")


#**time-indexing** is preformed so we can apply the moving average function in order to filter out high frequency variability in the time-series 
ts_l0 <- zoo(n_l0$`Intensity [Lux]`, order.by = n_l0$`Timestamp [UTC+1]`)
ts_l8 <- zoo(n_l8$`Intensity [Lux]`, order.by = n_l8$`Timestamp [UTC+1]`)
ts_l8m <- zoo(n_l8m$`Intensity [Lux]`, order.by = n_l8m$`Timestamp [UTC+1]`)


#low-frequency filtering of data using moving average that is applied within window size on time series data (ts_l0, ts_l8, ts_l8m)
#**window size determines the magnitude of low frequency filtering**
#1 min to 30 min - 30, 1 h - 60, 3 h - 180, 6 - 360 
#5 min to 30 min - 6, 1 h - 12, 3 h - 36, 6 h - 72

#**0 m**
#**30 min**
l0_0.5h <- rollapply(ts_l0, 
                 width = 30, 
                 FUN = mean, 
                 align = "center", 
                 fill = NA)  #applying the moving average over the time series 
time <- index(ts_l0)
start_time <- min(time)
end_time <- max(time)
x <- seq.POSIXt(from = start_time, to = end_time, by = "30 min")
l0_0.5h <- aggregate(l0_0.5h, as.POSIXct(cut(time, breaks = x)), FUN = mean)

#**1 hour**
l0h <- rollapply(ts_l0, 
                 width = 60, 
                 FUN = mean, 
                 align = "center", 
                 fill = NA)  #applying the moving average over the time series 
x <- seq.POSIXt(from = start_time, to = end_time, by = "hour")
l0h <- aggregate(l0h, as.POSIXct(cut(time, breaks = x)), FUN = mean)


#**3 hours**
l0_3h <- rollapply(ts_l0, 
                 width = 180, 
                 FUN = mean, 
                 align = "center", 
                 fill = NA)  
x <- seq.POSIXt(from = start_time, to = end_time, by = "3 hours")
l0_3h <- aggregate(l0_3h, as.POSIXct(cut(time, breaks = x)), FUN = mean)


#**6 hours**
l0_6h <- rollapply(ts_l0, 
                   width = 360, 
                   FUN = mean, 
                   align = "center", 
                   fill = NA)  
x <- seq.POSIXt(from = start_time, to = end_time, by = "6 hours")
l0_6h <- aggregate(l0_6h, as.POSIXct(cut(time, breaks = x)), FUN = mean)

#**in order to plot, we set time series into tibble**
l0_0.5h <- tidy(l0_0.5h) #tidy function creates a data frame 
colnames(l0_0.5h)[1] <- "Timestamp [UTC+1]"
colnames(l0_0.5h)[2] <- "Intensity [Lux]"

l0h <- tidy(l0h) 
colnames(l0h)[1] <- "Timestamp [UTC+1]"
colnames(l0h)[2] <- "Intensity [Lux]"

l0_3h <- tidy(l0_3h) 
colnames(l0_3h)[1] <- "Timestamp [UTC+1]"
colnames(l0_3h)[2] <- "Intensity [Lux]"

l0_6h <- tidy(l0_6h) 
colnames(l0_6h)[1] <- "Timestamp [UTC+1]"
colnames(l0_6h)[2] <- "Intensity [Lux]"

#**plot together**
#dash: Sets the line type. It can be one of several options such as 'solid', 'dot', 'dash', 'longdash', 'dashdot', or 'longdashdot'.

plot_ly(data = n_l0, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines',
        line = list(color = 'lightgray', width = 2, dash = 'solid'),
        name = "raw 5 min interval")%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "Surface")%>% 
  add_lines(data = l0_0.5h,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'red', width = 2, dash = 'solid'),
            name = "30 min interval")%>%
  add_lines(data = l0h,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'blue', width = 2, dash = 'solid'),
            name = "1 hour interval")%>%
  add_lines(data = l0_3h,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'green', width = 2, dash = 'solid'),
            name = "3 hour interval")%>%
  add_lines(data = l0_6h,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'orange', width = 2, dash = 'solid'),
            name = "6 hour interval")
  
#**Task 4: Repeat the process for data at 8 meters (choose ts_l8m: raw 5 min interval time series)**
#**30 min**

#**a) 1 hour**

#**b) 3 hours**

#**c) 6 hours**

#**d) set tibble**

#**e) plot all together by replacing "x" with the data frames**
plot_ly(data = x, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines',
        line = list(color = 'lightgray', width = 2, dash = 'solid'),
        name = "raw 5 min interval")%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 meters")%>% 
  add_lines(data = x,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'red', width = 2, dash = 'solid'),
            name = "30 min interval")%>%
  add_lines(data = x,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines',
            line = list(color = 'blue', width = 2, dash = 'solid'),
            name = "1 hour interval")%>%
  add_lines(data = x,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'green', width = 2, dash = 'solid'),
            name = "3 hour interval")%>%
  add_lines(data = x,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'orange', width = 2, dash = 'solid'),
            name = "6 hour interval")


#**Task 5: Compare 5 minute interval data at 8 meters filtered from 1 min interval data with raw 5 min interval data at 8 meters**

#**a) choose window size for low-frequency filtering from 1 minute to 5 minute, and apply moving average**
#**b) set tibble**
#**c) plot and compare**
#**Are the curves a good match?**


#**Task 6: Plot surface and 8 meters together on one plot - choose different interval data and see how it changes**
plot_ly(data = x, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines',
        line = list(color = 'red', width = 2, dash = 'solid'),
        name = "0 m")%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "x time interval data")%>% 
  add_lines(data = x,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            line = list(color = 'blue', width = 2, dash = 'solid'),
            name = "8 m")

#**Save data**
#save data from environment to R.data for further use in another project
save(l0h, l8h, file = "one_hour_data_lux.RData")
#save data from environment as .csv file for further use in another program 
write.csv(l8h, "l8_1hour.csv")
