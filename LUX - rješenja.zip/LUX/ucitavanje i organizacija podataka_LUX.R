source("C:/Users/Antonija/OneDrive - Prirodoslovno-matematički fakultet/Radionica svjetlost/paketi_ucitavanje.R")

Sys.setlocale("LC_TIME", "C")
#* sets the locale for date and time functions to the default, language-independent settings. 
#* This can be particularly useful for ensuring consistent date and time formats across different environments 
#* and regions, as it avoids any localization issues that might arise from the system's locale settings.

#CHECK DIRECTORY
getwd()

#SET DIRECTORY
setwd()

#IMPORT DATA
l0 <- readr::read_delim("Zrmanja_3004-0205_0m_1min_GMT+2.csv", delim = ",", show_col_types = FALSE)
l8 <- readr::read_delim("Zrmanja_3004-0205_8m_1min_GMT+2.csv", delim = ",", show_col_types = FALSE)
l8m <- readr::read_delim("Zrmanja_3004-0305_8m_5min_GMT+2.csv", delim = ",", show_col_types = FALSE)

#set tibble
l0 <- as_tibble(l0)
l8 <- as_tibble(l8)
l8m <- as_tibble(l8m)

#see data in your console
l0
l8
l8m

#we can see that temperature and light are in "double" format which is good, however the Timestamp column is 
#a character vector and we need to transform it into date and time vector indicated by <dttm>

#**EDIT DATA**

#**function to define timestamp format <dttm>**: convert to 24-hour (remove AM/PM) and define format as %Y-%m-%d %H:%M:%S
timestamp_format <- function(x) {
  #timestamp structure we are converting (must be the same as in our data frame)
  timestamp <- mdy_hms(x)
  #convert timestamp to the desired format
  formatted_timestamp <- format(timestamp, "%Y-%m-%d %H:%M:%S")
  return(formatted_timestamp)
  }

#set format using function timestamp_format():
l0$`Timestamp [GMT+02:00]` <- sapply(l0$`Timestamp [GMT+02:00]`, timestamp_format)

#define as date and time vector <dttm>  using POSIXct(): 
l0$`Timestamp [GMT+02:00]` <- as.POSIXct(l0$`Timestamp [GMT+02:00]`)

#convert timestamp from GMT+02:00 to UTC+01:00 using with_tz():
l0$`Timestamp [GMT+02:00]` <- with_tz(l0$`Timestamp [GMT+02:00]`, tzone = "Europe/London")

#change column name 
colnames(l0)[2] <- "Timestamp [UTC+1]"

#check the format of the vector and name
l0

#**repeat for l8 and l8m**
l8$`Timestamp [GMT+02:00]` <- sapply(l8$`Timestamp [GMT+02:00]`, timestamp_format)
l8$`Timestamp [GMT+02:00]` <- as.POSIXct(l8$`Timestamp [GMT+02:00]`)
l8$`Timestamp [GMT+02:00]` <- with_tz(l8$`Timestamp [GMT+02:00]`, tzone = "Europe/London")
colnames(l8)[2] <- "Timestamp [UTC+1]"
l8

l8m$`Timestamp [GMT+02:00]` <- sapply(l8m$`Timestamp [GMT+02:00]`, timestamp_format)
l8m$`Timestamp [GMT+02:00]` <- as.POSIXct(l8m$`Timestamp [GMT+02:00]`)
l8m$`Timestamp [GMT+02:00]` <- with_tz(l8m$`Timestamp [GMT+02:00]`, tzone = "Europe/London")
colnames(l8m)[2] <- "Timestamp [UTC+1]"
l8m


#**plotly** plot using package for interactive plots plot_ly
plot_ly(data = l0, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines')%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "Surface - raw data 1 min interval")

plot_ly(data = l8, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines')%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
        yaxis = list(title = "Light intensity (Lux)",
                     tickformat = ".1e"),
        title = "8m - raw data 1 min interval")


plot_ly(data = l8m, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines') %>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8m - raw data 5 min interval")



