source("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/Radionica svjetlost/paketi_ucitavanje.R")

Sys.setlocale("LC_TIME", "C")


n_l0 <- l0 %>% filter(`Intensity [Lux]` < 10000)


plot_ly(data = n_l0, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines')%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "Surface - 1 min interval without extremes")


n_l8 <- l8 %>% filter(`Intensity [Lux]` < 2000)

plot_ly(data = n_l8, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines')%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 m - 1 min interval without extremes")


n_l8m <- l8m %>% filter(`Intensity [Lux]` < 2000)

plot_ly(data = n_l8m, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines')%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 m -5 min interval without extremes")

#plot light at 8 m to compare in 1 min and 5 min interval data
plot_ly(data = n_l8m, 
        x = ~`Timestamp [UTC+1]`, 
        y = ~`Intensity [Lux]`,  
        type = 'scatter', 
        mode = 'lines',
        name = "raw 5 min time interval")%>% 
  layout(xaxis = list(title = "Date in 2024 (UTC+1)"), 
         yaxis = list(title = "Light intensity (Lux)",
                      tickformat = ".1e"),
         title = "8 m : 5 min interval data")%>% 
  add_lines(data = n_l8,
            x = ~ `Timestamp [UTC+1]`, 
            y = ~ `Intensity [Lux]`,  
            type = 'scatter', 
            mode = 'lines', 
            name = "filtered from 1 min time interval")
